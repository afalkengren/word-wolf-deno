//import { WSMessage, WSMessageType, WSMessageDataChat, WSMessageData, WSMessageDataInit } from "../shared/ws_interfaces";
var WSMessageType;
(function (WSMessageType) {
    WSMessageType[WSMessageType["init"] = 0] = "init";
    WSMessageType[WSMessageType["connect"] = 1] = "connect";
    WSMessageType[WSMessageType["chat"] = 2] = "chat";
})(WSMessageType || (WSMessageType = {}));
let container;
let chatFlexBox;
let chatSendBtn;
let chatMsgField;
document.addEventListener('DOMContentLoaded', initOnPageLoad.bind(this));
let selfName = "";
// Chat Messages
class ChatMessage {
    constructor(wsData) {
        this.id = wsData.id;
        this.from = wsData.from;
        this.body = wsData.body;
        this.isDeleted = false;
        this.element = undefined;
    }
}
const chatMessages = new Map();
// Websocket
const ws = new WebSocket(`wss://${location.host}/ws`);
ws.addEventListener("message", handleWebSocketMessage);
function handleWebSocketMessage(e) {
    const msg = JSON.parse(e.data);
    switch (msg.type) {
        case WSMessageType.init:
            console.log("[WS INIT]:", e.data);
            const initData = msg.data;
            selfName = initData.name;
            document.getElementById("room-code").innerText = String(initData.roomCode);
            document.getElementById("loading-text").style.display = "none";
            container.style.display = "flex";
            break;
        case WSMessageType.connect:
            console.log("[WS CONN]:", e.data);
            break;
        case WSMessageType.chat:
            console.log("[WS CHAT]:", e.data);
            const chatData = msg.data;
            const chatMessage = new ChatMessage(chatData);
            chatMessages.set(chatData.id, chatMessage);
            addMessage(chatMessage);
            break;
        default:
            console.log("[WS UNKNOWN!]", e.data);
    }
}
// init events
function initOnPageLoad() {
    container = document.getElementById("container");
    chatFlexBox = document.getElementById("chat-box");
    chatSendBtn = document.getElementById("chat-input_send");
    chatMsgField = document.getElementById("chat-input_textfield");
    chatSendBtn.addEventListener("click", sendButtonClick);
}
function sendButtonClick(ev) {
    const text = chatMsgField.innerText;
    chatMsgField.innerText = "";
    sendMessage(text);
}
// functions
function sendMessage(body) {
    const msgData = { id: WSMessageType.chat, from: selfName, body: body };
    const msg = { type: WSMessageType.chat, data: msgData };
    ws.send(JSON.stringify(msg));
}
function addMessage(msg) {
    msg.element = addMessageToDOM(String(msg.id), msg.body);
}
function addMessageToDOM(id, msg) {
    let msgDiv = document.createElement("div");
    msgDiv.setAttribute("id", id);
    msgDiv.setAttribute("class", "chat__message");
    msgDiv.innerText = msg;
    chatFlexBox.appendChild(msgDiv);
    return msgDiv;
}
//# sourceMappingURL=client_game.js.map